INSERT INTO `payments` (`id`, `type`, `name`, `min`, `max`, `new_users`, `status`, `params`) VALUES
(190, 'flutterwave', 'Flutterwave', 20, 1000, 1, 1, '{"type":"flutterwave","name":"Flutterwave","min":"20","max":"1000","new_users":"1","status":"1","option":{"tnx_fee":"0","environment":"live","public_key":"","secret_key":"","encryption_key":"","currency_code":"NGN","rate_to_usd":"1"}}');
