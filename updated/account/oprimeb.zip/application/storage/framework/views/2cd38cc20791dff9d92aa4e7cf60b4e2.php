<?php
$about = getContent('about.content',true);
?>

<!--========================== About Section Start ==========================-->
<div class="about-section pt-80 pb-100">
    <div class="container">
        <div class="row gy-4 align-items-center">

            <div class="col-lg-6 position-relative">
                <div class="about-right-content">
                     <div class="section-heading mb-0">
                        <span class="subtitle"><?php echo e(__($about->data_values->top_heading)); ?></span>
                         <h2 class="section-heading__title">
                            <?php echo e(__($about->data_values->heading)); ?>

                         </h2>
                         <p class="section-heading__desc mb-3"><?php echo e(__($about->data_values->description1)); ?></p>

                             <p class="section-heading__desc mb-4"><?php echo e(__($about->data_values->description2)); ?></p>
                         <div class="about-bottom">
                            <a href="<?php echo e(url('/about')); ?>" class="btn btn--base me-3 mb-2">
                                <?php echo app('translator')->get('View More'); ?> <i class="fas fa-arrow-right"></i>
                            </a>
                         </div>
                     </div>
                </div>
            </div>

            <div class="col-lg-6 position-relative">
                <div class="about-thumb">
                    <div class="about-thumb__inner">
                        <img class="img-2" src="<?php echo e(getImage(getFilePath('about').'/'.@$about->data_values->about_image)); ?>" alt="image">
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!--========================== About Section End ==========================-->
<?php /**PATH C:\xampp\htdocs\smm\application\resources\views/presets/default/sections/about.blade.php ENDPATH**/ ?>