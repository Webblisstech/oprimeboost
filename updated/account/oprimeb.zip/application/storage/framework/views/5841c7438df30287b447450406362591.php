<?php
$counterElements = getContent('counter.element',false,4);
?>


<!-- ==================== Experience Start Here ==================== -->
<section class="experience-area section-bg py-80 ">
    <div class="container">
        <div class="row gy-4 justify-content-center">
            <?php $__currentLoopData = $counterElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4">
                <div class="experience">
                    <div class="experience__icon">
                        <?php
                        echo $item->data_values->counter_icon;
                        ?>
                    </div>
                    <div class="experience__count">
                        <h3><span class="odometer" data-count="<?php echo e(__($item->data_values->counter_digit)); ?>">00</span><span class="letter">+</span></h3>
                    </div>
                    <div class="experience__content">
                        <h3 class="title"><?php echo e(__($item->data_values->title)); ?></h3>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- ==================== Experience End Here ==================== -->
<?php /**PATH /home/aquantuo/public_html/smm.aquantuoservices.com/application/resources/views/presets/default/sections/counter.blade.php ENDPATH**/ ?>