<?php $__env->startSection('content'); ?>

<?php
$banner = getContent('banner.content', true);
?>

<!--========================== Banner Section Start ==========================-->
<section class="banner-section">
    <img class="shape-banner-bg" src="<?php echo e(asset($activeTemplateTrue.'images/shape-bg.png')); ?>" alt="shape">
    <div class="container">
        <div class="row gy-4 align-items-center">
            <div class="col-lg-6">
                  <div class="banner-left__content">
                    <span class="subtitle"><?php echo e(__($banner->data_values->top_heading)); ?></span>
                      <h2><?php echo e(__($banner->data_values->heading)); ?></h2>
                      <p><?php echo e(__($banner->data_values->sub_heading)); ?></p>
                      <a href="<?php echo e(url('/contact')); ?>" class="btn btn--base me-2 mb-2">
                        <?php echo e(__($banner->data_values->banner_button)); ?> <i class="fas fa-arrow-right"></i>
                      </a>
                  </div>
              </div>
            <div class="col-lg-6">
              <div class="banner-right-wrap position-relative">
                <div class="banner-thumb">
                  <img class="experience-text " src="<?php echo e(getImage(getFilePath('banner').'/'.@$banner->data_values->banner_image)); ?>" alt="Main-Image">
                  <img class="banner-social linkdin animate-x-axis" src="<?php echo e(getImage(getFilePath('banner').'/'.@$banner->data_values->banner_social_image1)); ?>" alt="Side-image1">
                  <img class="banner-social pintarest animate-y-axis" src="<?php echo e(getImage(getFilePath('banner').'/'.@$banner->data_values->banner_social_image2)); ?>" alt="Side-image2">
                  <img class="banner-social insta animate-y-axis" src="<?php echo e(getImage(getFilePath('banner').'/'.@$banner->data_values->banner_social_image3)); ?>" alt="Side-image2">

                </div>
              </div>
            </div>
        </div>
    </div>
  </section>
<!--========================== Banner Section End ==========================-->

<?php if($sections->secs != null): ?>
<?php $__currentLoopData = json_decode($sections->secs); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make($activeTemplate.'sections.'.$sec, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aquantuo/public_html/smm.aquantuoservices.com/application/resources/views/presets/default/home.blade.php ENDPATH**/ ?>