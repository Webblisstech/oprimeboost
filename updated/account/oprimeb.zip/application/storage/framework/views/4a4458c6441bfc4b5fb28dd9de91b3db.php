<?php $__env->startSection('panel'); ?>
<?php echo $__env->make('admin.components.tabs.order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card b-radius--10 ">
            <div class="card-body p-0">
                <div class="table-responsive--sm table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Order No'); ?></th>
                                <th><?php echo app('translator')->get('Category Name'); ?></th>
                                <th><?php echo app('translator')->get('Service Name'); ?></th>
                                <th><?php echo app('translator')->get('User Name'); ?></th>
                                <th><?php echo app('translator')->get('Link'); ?></th>
                                <th><?php echo app('translator')->get('Price'); ?></th>
                                <th><?php echo app('translator')->get('Start Counter'); ?></th>
                                <th><?php echo app('translator')->get('Remain Counter'); ?></th>
                                <th><?php echo app('translator')->get('Api Order'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>

                                <td>#<?php echo e(__($item->order_no)); ?></td>
                                <td><?php echo e(__(@$item->category->name)); ?></td>
                                <td><?php echo e((@$item->service->name)); ?></td>
                                <td><?php echo e(__($item->user->username)); ?></td>
                                <td><a href="<?php echo e(__($item->link)); ?>" target="_blank"><?php echo e(__($item->link)); ?></a></td>
                                <td><?php echo e($general->cur_sym); ?> <?php echo e(showAmount($item->price)); ?></td>
                                <td><?php echo e(__($item->start_count)); ?></td>
                                <td><?php echo e(__($item->remain_count)); ?></td>
                                <td>
                                    <?php if($item->api_order): ?>
                                        <span class="badge  badge--primary"><?php echo app('translator')->get('Yes'); ?></span>
                                    <?php else: ?>
                                        <span class="badge  badge--warning"><?php echo app('translator')->get('No'); ?></span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php
                                        echo $item->statusBadge($item->status);
                                    ?>
                                </td>

                                <td>
                                    <button title="<?php echo app('translator')->get('Edit'); ?>"
                                     data-id="<?php echo e($item->id); ?>" data-start_count="<?php echo e($item->start_count); ?>" data-remain_count="<?php echo e($item->remain_count); ?>"
                                     data-status="<?php echo e($item->status); ?>"
                                        class="btn btn-sm btn--primary countUpdate">
                                        <i class="las la-edit"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                            </tr>
                            <?php endif; ?>

                        </tbody>
                    </table><!-- table end -->
                </div>
            </div>
            <?php if($orders->hasPages()): ?>
            <div class="card-footer py-4">
                <?php echo e(paginateLinks($orders)); ?>

            </div>
            <?php endif; ?>
        </div><!-- card end -->
    </div>
</div>



<div id="countUpdateModel" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo app('translator')->get('Update'); ?></h5>
                <button type="button" class="close btn btn--danger" data-bs-dismiss="modal" aria-label="Close">
                    <i class="las la-times"></i>
                </button>
            </div>
            <form action="<?php echo e(route('admin.order.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id">
                <div class="modal-body">
                    <div class="form-group">
                        <label  for="name"> <?php echo app('translator')->get('Start Counter'); ?>:</label>
                        <?php if(@$item->status == 0 || @$item->status == 1): ?>
                        <input type="text" class="form-control" name="start_count">
                        <?php else: ?>
                        <span class="badge badge--success"><?php echo e(@$item->start_counter); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label  for="name"> <?php echo app('translator')->get('Status'); ?>:</label>
                        <?php if(@$item->status == 0  || @$item->status == 1): ?>
                        <select name="status" class="form-control">
                            <option value="0" <?php echo e(@$item->status == 0 ? 'selected' : ''); ?>><?php echo app('translator')->get('Pending'); ?></option>
                            <option value="1" <?php echo e(@$item->status == 1 ? 'selected' : ''); ?>><?php echo app('translator')->get('Processing'); ?></option>
                            <option value="2" <?php echo e(@$item->status == 2 ? 'selected' : ''); ?>><?php echo app('translator')->get('Completed'); ?></option>
                            <option value="3" <?php echo e(@$item->status == 3 ? 'selected' : ''); ?>><?php echo app('translator')->get('Cancelled'); ?></option>
                            <option value="4" <?php echo e(@$item->status == 4 ? 'selected' : ''); ?>><?php echo app('translator')->get('Refunded'); ?></option>
                        </select>
                        <?php elseif(@$item->status == 2): ?>
                            <span class="badge  badge--success"><?php echo app('translator')->get('Completed'); ?></span>
                        <?php elseif(@$item->status == 3): ?>
                            <span class="badge  badge--danger"><?php echo app('translator')->get('Cancelled'); ?></span>
                        <?php else: ?>
                            <span class="badge  badge--dark"><?php echo app('translator')->get('Refunded'); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if(@$item->status == 0 || @$item->status == 1): ?>
                <div class="modal-footer">
                    <button type="submit" class="btn btn--primary btn-global"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
<script>
    "use strict";
    $('.countUpdate').on('click', function () {
            var modal = $('#countUpdateModel');
            var statusValue = $(this).data('status');
            modal.find('select[name=status]').val(statusValue);
            modal.find('input[name=id]').val($(this).data('id'));
            modal.find('input[name=start_count]').val($(this).data('start_count'));
            modal.modal('show');
        });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aquantuo/public_html/smm.aquantuoservices.com/application/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>