<?php echo  loadExtension('tawk-chat') ?>
<?php echo  loadExtension('google-analytics') ?>
<?php /**PATH /home/aquantuo/public_html/smm.aquantuoservices.com/application/resources/views/includes/plugins.blade.php ENDPATH**/ ?>