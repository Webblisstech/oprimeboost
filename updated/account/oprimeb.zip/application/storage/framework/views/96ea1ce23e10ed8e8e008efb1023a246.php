<div class="row">
    <div class="col">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::routeIs('admin.order.index') ? 'active' : ''); ?>"
                    href="<?php echo e(route('admin.order.index')); ?>"><?php echo app('translator')->get('all'); ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::routeIs('admin.order.pending') ? 'active' : ''); ?>"
                    href="<?php echo e(route('admin.order.pending')); ?>"><?php echo app('translator')->get('Pending'); ?>
                    <?php if($pending): ?>
                    <span class="badge rounded-pill bg--white text-muted"><?php echo e($pending); ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::routeIs('admin.order.processing') ? 'active' : ''); ?>"
                    href="<?php echo e(route('admin.order.processing')); ?>"><?php echo app('translator')->get('Processing'); ?>
                    <?php if($processing): ?>
                    <span class="badge rounded-pill bg--white text-muted"><?php echo e($processing); ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::routeIs('admin.order.complete') ? 'active' : ''); ?>"
                    href="<?php echo e(route('admin.order.complete')); ?>"><?php echo app('translator')->get('Completed'); ?>
                    <?php if($complete): ?>
                    <span class="badge rounded-pill bg--white text-muted"><?php echo e($complete); ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::routeIs('admin.order.refund') ? 'active' : ''); ?>"
                    href="<?php echo e(route('admin.order.refund')); ?>"><?php echo app('translator')->get('Refunded'); ?>
                    <?php if($refund): ?>
                    <span class="badge rounded-pill bg--white text-muted"><?php echo e($refund); ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::routeIs('admin.order.cancel') ? 'active' : ''); ?>"
                    href="<?php echo e(route('admin.order.cancel')); ?>"><?php echo app('translator')->get('Cancelled'); ?>
                    <?php if($cancelled): ?>
                    <span class="badge rounded-pill bg--white text-muted"><?php echo e($cancelled); ?></span>
                    <?php endif; ?>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH /home/aquantuo/public_html/smm.aquantuoservices.com/application/resources/views/admin/components/tabs/order.blade.php ENDPATH**/ ?>